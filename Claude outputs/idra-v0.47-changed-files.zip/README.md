# IDRA: Infinite Differential Roll Arm

A 6-axis desk robot arm with a **wrist that spins endlessly**: the roll joint has no end stop and never has to unwind. Two bevel differentials move elbow and wrist. *Idra* is Italian for hydra.

[![IDRA in the simulator, with a slice of its reachable space](docs/assets/preview.png)](https://enricomichelato.github.io/Idra/)

**[▶ Drive IDRA in your browser](https://enricomichelato.github.io/Idra/)**: press an arrow key and you are in control. Works on any computer; on a phone there is an on-screen pad. Nothing to install.

IDRA is a design model: nothing has been built yet.

## Keyboard control

The simulator has a keyboard deck under the 3D view: the keys light up as you press them, and you can click them too. You move the grip and the arm works out all six joints by itself. The first movement key takes control.

| Keys | What they do |
|---|---|
| ← → | orbit around the base (cylindrical mode) |
| ↑ ↓ | reach out and pull in |
| W / S | up and down |
| A / D | tilt the hand |
| Q / E | spin the hand, endlessly |
| Z / X | close and open the fingers |
| M | switch mode: cylindrical, view, hand, joints |
| O | hand follows the arm, or stays fixed in space |
| P | ready pose |
| Shift | fast |
| R / F | forearm pronation (joints mode) |
| C / Esc | take / release control |

When a move is impossible, the panel in the top left says why: out of reach, a joint limit, or fingers on the desk. **Reachable space** draws the cloud of points the grip can reach.

More: **[kinematics, step by step](https://enricomichelato.github.io/Idra/kinematics.html)**.

## What makes it different

- **Endless roll.** The hand turns without limit: the roll joint has no end stop, and the firmware never has to unwind it.
- **Three-finger hand.** Fin Ray fingers driven by one self-locking steel worm and a smart servo: the grip holds with the power off, and the hand knows the finger position and the grip force.
- **Two bevel differentials.**
  - **Elbow:** flexion and pronation from two motors, module 3 spiral bevels and an idler satellite.
  - **Wrist:** pitch and roll, with its motors placed near the elbow so there is less weight at the tip.
- **Bones on the outside.** The aluminium plates are the outermost parts at every joint, like an insect's shell; the elbow cradle and the wrist flange turn between them.
- **Joint encoders.** Magnetic encoders read the joints after the belts: base, elbow flexion and pronation, wrist pitch and roll.
- **Built from scripts.** Waterjet-cut steel and aluminium plates and about 50 printed parts that fit a 256 × 256 mm bed. Every part comes from CadQuery scripts, and a fit test coupon tunes bearing seats and holes to your printer.

## Numbers

| | |
|---|---|
| Axes | 6: base, shoulder, elbow, pronation, wrist pitch, endless wrist roll |
| Lengths | upper arm 229 mm, forearm 290 mm; grip centre 194 mm from the wrist centre |
| Reach | about 710 mm to the grip; picks fingers-down on the desk up to 50 cm from the base; shoulder axis 216 mm above the desk |
| Target payload | 1 kg at the wrist flange; gravity-balance springs at the shoulder |
| Structure | bones in identical pairs with diagonal truss slots: upper arm and shoulder cheeks waterjet-cut 4 mm steel, with the shoulder teeth cut in the bones (`mechanical/cad/LASER_CUT.md`), forearm printed PETG-CF; through-bolts instead of covers; printed PETG / PETG-CF for the rest |
| Motors | 2 × NEMA23 with 10:1 planetaries at the shoulder, on teeth cut in the steel bones (28:1, one per bone, ±90°), 6 × NEMA17 (two on the base, 48.7:1 with 5:1 planetaries, preloaded; two 48 mm at the elbow, 44:1 through two belt stages; two at the wrist, 5:1), Feetech STS3215 servo in the hand |
| Grip | about 18 N per finger, holds about 1 kg by friction (estimate) |
| Electronics | ESP32-S3 + 6 × TMC2209 in the base; a camera on the wrist is planned |
| Reference printer | Elegoo Centauri Carbon |

## Status

| Part | Status |
|---|---|
| CAD: arm v0.47, wrist v1.39, hand v3.0 | about 50 printed parts with oriented STLs, 2 DXFs (steel upper-arm bones and cheeks, 4 plates), every joint has its fasteners; nothing built yet |
| Forward and inverse kinematics, joints → motors | done and verified (`control/`) |
| Hand electronics | schematic with starting values, bench test pending |
| Firmware | not started |
| Printing and assembly | `mechanical/cad/PRINT_LIST.md`, `mechanical/cad/ASSEMBLY.md` |
| Still to model | cable connectors, small-part fixings (see `mechanical/cad/BOM.md`) |

## Layout

```
docs/                    GitHub Pages site (built by tools/build_site.py)
mechanical/cad/
  arm_v0/                base, shoulder, upper arm, elbow, forearm + 3D viewer (viewer_build.py)
  wrist_v0/              wrist differential and hand (hand_v3.py, export_print.py; hand_v2.py kept for reference)
  common/                fit.py (print clearances) and the fit test coupon
  BOM.md                 hardware list
  LASER_CUT.md           the four aluminium bones: DXF files and finishing
  PRINT_LIST.md          every printed part: file, quantity, material, supports
  ASSEMBLY.md            assembly order, fasteners per joint, bench tests
  WRIST_BUILD.md         building the wrist and hand alone on the bench: what to print and buy (tools/wrist_kit.py)
control/                 kinematics.py (forward, inverse, motor mixing), dynamics.py (torques, motor sizing), hand_grip.py, stiffness.py (each writes a *_report.md)
electronics/             hand electronics: schematics (schemdraw) and page
tools/                   site build, print audit, oriented STL export, DXF export, mass model from the CAD
  checks/                interference checks (arm, wrist, hand) and kinematics self-test
STATUS.md                where the project stands, how to regenerate and check everything, open items
```

Design notes: [base and electronics](mechanical/cad/arm_v0/base_notes.md) · [hand: printing and assembly](mechanical/cad/wrist_v0/hand_print_notes.md) · [fit test](mechanical/cad/common/fit_test.md) · [kinematics](control/kinematics.md) · [BOM](mechanical/cad/BOM.md)

## Rebuilding models and pages

```bash
pip install -r requirements.txt
cd mechanical/cad/arm_v0 && python3 viewer_build.py         # whole arm + 3D viewer (about 10 minutes)
python3 viewer_build.py --tpl                               # page only, reusing the cached meshes
cd ../wrist_v0 && python3 export_print.py                   # hand STLs, already oriented for printing
cd ../common && python3 fit_test.py                         # fit test coupon
cd ../../../electronics && python3 hand_passive_schematic.py && python3 build_page.py
cd .. && python3 tools/build_site.py --preview              # refresh docs/ (the preview needs Playwright)
```

STLs and other generated files are not in the repository: they go to the `out/` folders. The full list of commands and the checks to run after a change are in [STATUS.md](STATUS.md).

## Licence

Copyright © 2026 Enrico Michelato. **All rights reserved.** You may read the files and run the simulator, but no licence is granted to copy, modify, build, distribute or use this design, in whole or in part, without written permission. See [LICENSE](LICENSE).
